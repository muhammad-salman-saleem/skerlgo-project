import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';

@Component({
  selector: 'app-choose-langue',
  templateUrl: './choose-langue.page.html',
  styleUrls: ['./choose-langue.page.scss'],
})
export class ChooseLanguePage implements OnInit {

  
  langue: any;

  constructor(
    private nav: NavController) { }

  ngOnInit() {
  }

  choose_langue(langue) {
    this.langue = langue;
  }

  goTo() {
    if(this.langue){
      window.localStorage['appLang'] = this.langue;
      this.nav.navigateRoot('/tabs/home');
    }
  }

  

}
